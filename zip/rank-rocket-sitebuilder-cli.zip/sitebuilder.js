// Main orchestrator script
