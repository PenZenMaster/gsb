// Parses sitemap XML
