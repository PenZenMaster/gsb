// Downloads and cleans HTML content
